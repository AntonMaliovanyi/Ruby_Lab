class ContactsController < ApplicationController
  before_action :set_contact, only: %i[show edit update destroy]

  def index
    @contacts = Contact.all
  end

  def show
  end

  def new
    @contact = Contact.new
  end

 # app/controllers/contacts_controller.rb
  def create
    @contact = Contact.new(contact_params)

    # Перевірка наявності користувача в базі
    user = User.find_by(name: params[:contact][:name])

    if user.nil?
      # Створення нового користувача, якщо його немає
      user = User.create(name: params[:contact][:name])
      flash.now[:notice] = "User was created."
    end

    @contact.user = user

    if @contact.save
      flash[:notice] = "Contact was successfully created."
      redirect_to contacts_path
    else
      flash.now[:alert] = @contact.errors.full_messages.to_sentence
      render :new, status: :unprocessable_entity
    end
  end

  def edit
  end

  def update
    if @contact.update(contact_params)
      redirect_to @contact, notice: "Contact successfully updated."
    else
      render :edit, status: :unprocessable_entity
    end
  end

  def destroy
    @contact.destroy
    redirect_to contacts_path, notice: "Contact deleted."
  end

  private

  def set_contact
    @contact = Contact.find(params[:id])
  end

  def contact_params
    params.require(:contact).permit(:name)
  end

end
